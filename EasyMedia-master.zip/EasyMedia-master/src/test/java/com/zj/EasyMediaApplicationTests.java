package com.zj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EasyMediaApplicationTests {

	@Test
	void contextLoads() {
	}

}
