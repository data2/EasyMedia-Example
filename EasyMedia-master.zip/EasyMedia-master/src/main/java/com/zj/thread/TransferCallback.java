package com.zj.thread;

/**
 * 转码回调
 * @author ZJ
 *
 */
public interface TransferCallback {

	public void start(boolean startSuccess);
}
